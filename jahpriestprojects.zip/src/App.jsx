import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";

const Home = () => (
  <div style={{ padding: "20px" }}>
    <h1>Jah Priest Projects</h1>
    <p>Reggae Superstar | Songwriter | Artist | Nigeria</p>
    <video controls width="100%">
      <source src="/media/sample-video.mp4" type="video/mp4" />
    </video>
    <audio controls width="100%" style={{ marginTop: "20px" }}>
      <source src="/media/sample-audio.mp3" type="audio/mpeg" />
    </audio>
  </div>
);

const Fans = () => (
  <div style={{ padding: "20px" }}>
    <h2>Join Jah Priest's Fanbase</h2>
    <form>
      <input type="text" placeholder="Your Name" /><br />
      <input type="email" placeholder="Email Address" /><br />
      <button type="submit">Join Now</button>
    </form>
  </div>
);

const Interaction = () => (
  <div style={{ padding: "20px" }}>
    <h2>Fan Interaction</h2>
    <form>
      <textarea placeholder="Leave a message for Jah Priest..." rows="4" cols="50"></textarea><br />
      <button type="submit">Send Message</button>
    </form>
    <div>
      <h3>Recent Messages</h3>
      <ul>
        <li>"Love your music Jah Priest!" – A Fan</li>
        <li>"Keep the reggae vibes alive!" – RootsLover88</li>
      </ul>
    </div>
  </div>
);

const Store = () => (
  <div style={{ padding: "20px" }}>
    <h2>Buy Jah Priest's Tracks</h2>
    <h3>Hot Reggae Single - $1.99</h3>
    <button>Buy Now</button>
  </div>
);

const App = () => (
  <Router>
    <nav style={{ padding: "10px", backgroundColor: "#222", color: "#fff" }}>
      <a href="/" style={{ margin: "10px", color: "#fff" }}>Home</a>
      <a href="/fans" style={{ margin: "10px", color: "#fff" }}>Fan Club</a>
      <a href="/interact" style={{ margin: "10px", color: "#fff" }}>Interact</a>
      <a href="/store" style={{ margin: "10px", color: "#fff" }}>Store</a>
    </nav>
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/fans" element={<Fans />} />
      <Route path="/interact" element={<Interaction />} />
      <Route path="/store" element={<Store />} />
    </Routes>
  </Router>
);

export default App;