import React from "react";
import { Routes, Route, Link } from "react-router-dom";

const Home = () => (
  <div>
    <h1>Jah Priest Projects</h1>
    <p>Reggae Superstar | Songwriter | Artist | Nigeria</p>
    <h2>Watch My Videos</h2>
    {/* Embed video players or links */}
    <h2>Listen to My Audio</h2>
    {/* Embed audio players or links */}
  </div>
);

const Fans = () => (
  <div>
    <h2>Join Jah Priest's Fanbase</h2>
    <button>Join Now</button>
  </div>
);

const Interaction = () => (
  <div>
    <h2>Fan Interaction</h2>
    <textarea placeholder="Send a message..."></textarea>
    <button>Send Message</button>
    <h3>Recent Messages</h3>
    <ul>
      <li>"Love your music Jah Priest!" – A Fan</li>
      <li>"Keep the reggae vibes alive!" – RootsLover88</li>
    </ul>
  </div>
);

const Store = () => (
  <div>
    <h2>Buy Jah Priest's Tracks</h2>
    <h3>Hot Reggae Single - $1.99</h3>
    <button>Buy Now</button>
  </div>
);

const App = () => (
  <>
    <nav>
      <Link to="/">Home</Link> |{" "}
      <Link to="/fans">Fan Club</Link> |{" "}
      <Link to="/interact">Interact</Link> |{" "}
      <Link to="/store">Store</Link>
    </nav>
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/fans" element={<Fans />} />
      <Route path="/interact" element={<Interaction />} />
      <Route path="/store" element={<Store />} />
    </Routes>
  </>
);

export default App;
